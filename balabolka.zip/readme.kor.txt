﻿Balabolka, version 2.15.0.908
Copyright (c) 2006-2025 Ilya Morozov
All Rights Reserved

WWW: https://www.cross-plus-a.com/kr/balabolka.htm
E-mail: crossa@list.ru

라이선스: 프리웨어
운영 체제: Microsoft Windows 7/8/10/11
Microsoft Speech API: v4.0/5.0 and above
Microsoft Speech Platform: v11.0



*** 설치 ***

    이 Balabolka 버전을 ZIP 파일( 예: BALABOLKA.ZIP)로 받은 경우 다음과 같이 설치할 수 있습니다:

    1. 파일을 TEMP 디렉터리로 압축 해제합니다.
    2. 작업 표시줄 시작 메뉴에서 실행을 선택합니다.
    3. 파일의 전체 이름을 입력합니다 (예: C:\TEMP\SETUP.EXE).
    4. Enter 키를 누르고 프롬프트를 따릅니다.

    대화 상자 없이 Balabolka를 무음 모드로 설치하려면 무음 설치를 사용할 수 있습니다.
    "-silent" 명령줄 스위치를 사용하여 자동 설치 및 제거가 가능합니다.



*** Text-To-Speech 엔진 ***

    Balabolka는 텍스트 파일을 읽어주기 위해 텍스트 음성 변환 (TTS) 엔진을 사용합니다.
    음성 엔진이 설치되어 있다면 Balabolka 메인 창에 사용 가능한 음성 목록이 표시됩니다.

    이 프로그램은 SAPI 4와 SAPI 5 텍스트 음성 변환 엔진을 모두 지원합니다.
    SAPI 4는 더 이상 사용되지 않는 기술이므로 SAPI 5 사용을 권장합니다.

    더 높은 품질의 음성에 관심이 있으시다면 Balabolka 도움말 파일에서 자세한 내용을 확인하세요.



*** Microsoft Speech Platform ***

    Microsoft Speech Platform은 런타임과 런타임 언어 (음성 인식 및 텍스트 음성 변환 엔진)로 구성됩니다.
    음성 인식과 음성 합성을 위한 별도의 런타임 언어가 있습니다.

    https://msdn.microsoft.com/en-us/library/hh361572.aspx

    다음 단계에 따라 Microsoft Speech Platform을 설치하세요.

    1 컴퓨터에서 이전 버전의 Speech Platform Runtime을 제거합니다.
    2 32비트 또는 64비트 운영 체제를 사용하는지 확인합니다.
    3 운영 체제에 맞는 Speech Platform Runtime을 다운로드하여 설치합니다.
    4 Speech Platform에서 사용할 Runtime Languages를 다운로드하여 설치합니다.

    Balabolka는 32비트 응용 프로그램입니다. Balabolka에서 사용하려면 Microsoft Speech Platform용 32비트 런타임 패키지를 설치해야 합니다.



*** 기부하기 ***

    Balabolka를 돕고 싶으시다면 저의 소프트웨어 Cross+A를 구매하세요:

    https://www.cross-plus-a.com/kr/

    사람들이 Cross+A에 돈을 지불하는 한, Balabolka는 무료 소프트웨어로 남을 것입니다.

    감사합니다!  

###